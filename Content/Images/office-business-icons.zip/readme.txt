Freebie: Office Business Icons (AI, EPS, PDF, PNG and PSD)

The icon set was designed by Manuella Langella (http://www.manuelalangella.com/) and released for Smashing Magazine and its readers.

- - - - - - - - - - - - - - - - - -


Dearest Smashing reader,

Thank you for downloading the set. This set is licensed under a Creative Commons Attribution-ShareAlike 4.0 International license (https://creativecommons.org/licenses/by-sa/4.0/). You can use the icons in your commercial as well as your personal works. You may modify the size, color or shape of the icons. No attribution is required, however, reselling of bundles or individual icons is prohibited. The icons may not be resold, sub-licensed, rented, transferred or otherwise made available for use.

Please always provide credits to the creator of the icon set and link to the article in which this freebie was released if you would like to spread the word.


Sincerely yours,

Smashing Magazine Team
www.smashingmagazine.com
